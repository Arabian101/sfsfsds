import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { Check, ChevronLeft, Minus, Plus, RefreshCcw, ShieldCheck, Truck } from 'lucide-react'
import { useState } from 'react'
import { ProductCard } from '@/components/ProductCard'
import products, { categoryLabels, getProduct } from '@/data/products'
import { MAX_QUANTITY, useCart } from '@/lib/cart'
import { formatEuro, img } from '@/lib/format'

export const Route = createFileRoute('/producten/$slug')({
  loader: ({ params }) => {
    const product = getProduct(params.slug)
    if (!product) throw notFound()
    return product
  },
  head: ({ loaderData }) => ({
    meta: loaderData ? [{ title: `JAEGER ${loaderData.name} — JAEGERscissors.nl` }] : [],
  }),
  component: ProductPage,
})

function ProductPage() {
  const product = Route.useLoaderData()
  const { add } = useCart()
  const [quantity, setQuantity] = useState(1)

  return (
    <div className="max-w-7xl mx-auto px-5 md:px-8 pt-10">
      <nav className="text-xs text-ivory/50 flex items-center gap-2">
        <Link to="/winkel" className="inline-flex items-center gap-1 hover:text-ivory"><ChevronLeft size={14} /> Collectie</Link>
      </nav>
      <div className="mt-8 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-7">
          <img src={img(product.image, 1400)} alt={product.name} className="w-full aspect-[4/3] object-cover" />
        </div>
        <div className="lg:col-span-5">
          <p className="eyebrow">{categoryLabels[product.category]}</p>
          <h1 className="font-display text-5xl md:text-6xl mt-3">{product.name}</h1>
          <p className="mt-8 font-display text-4xl">{formatEuro(product.price)}</p>
          <div className="mt-10 flex gap-3">
            <button onClick={() => { add(product.slug, quantity); setQuantity(1); }} className="btn-brass flex-1">In winkelwagen</button>
          </div>
        </div>
      </div>
    </div>
  )
}