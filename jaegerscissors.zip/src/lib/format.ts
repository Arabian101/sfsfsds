export function formatEuro(amount: number): string {
  return new Intl.NumberFormat('nl-NL', {
    style: 'currency',
    currency: 'EUR',
  }).format(amount);
}

export function img(path: string, width = 800, _height?: number): string {
  return `/.netlify/images?url=${encodeURIComponent(path)}&w=${width}&fm=jpg`;
}